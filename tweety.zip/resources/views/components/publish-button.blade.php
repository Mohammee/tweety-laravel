<button type="submit"
        class="bg-blue-400 hover:bg-blue-600 shadow
                     text-white font-bold py-2 px-8 rounded-full">
    Publish
</button>

