<x-app>


    @include('_publish_tweet_panel')

    @include('_timeline')


</x-app>
