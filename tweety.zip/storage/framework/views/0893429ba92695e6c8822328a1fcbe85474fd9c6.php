<form  method="POST" action="<?php echo e(route('follow',$user)); ?>">
    <?php echo csrf_field(); ?>
    <button type="submit"
            class="bg-blue-400 hover:bg-blue-600  text-xs
                     text-white font-bold py-2 px-4 rounded-full">
        <?php echo e(auth()->user()->following($user) ? 'Un Follow' : 'Follwo Me'); ?>

    </button>
</form>
<?php /**PATH C:\PHPproject\laravelproject\tweety\resources\views/components/follow_button.blade.php ENDPATH**/ ?>