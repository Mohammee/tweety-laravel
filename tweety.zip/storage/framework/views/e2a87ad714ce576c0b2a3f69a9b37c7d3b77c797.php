<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.app','data' => []]); ?>
<?php $component->withName('app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

        <?php if($notification->type === 'App\Notifications\UserFollowed'): ?>
            <div class="border-l-4 border-blue-500 rounded-lg">
                <div class="flex w-full bg-white shadow-lg rounded-lg overflow-hidden border border-gray-300 mb-2">
                    <div class="px-2 py-3 flex">
                        <img class="w-12 h-12 object-cover rounded-full mt-4" src="<?php echo e($notification->data['avatar']); ?>">
                        <div class="px-2">
                            <h2 class="text-xl font-semibold text-gray-800">You have <?php echo e($notification->data['follow']); ?> <a
                                    href="<?php echo e(route('profile' , $notification->data['username'])); ?>"
                                    class="text-blue-500"><?php echo e('@' . $notification->data['username']); ?></a>
                            </h2>
                        </div>
                    </div>

                </div>
            </div>
        <?php endif; ?>

        <?php if($notification->type === 'App\Notifications\NewTweet'): ?>
            <div class="border-l-4 border-blue-500 rounded-lg">
                <div class="flex w-full bg-white shadow-lg rounded-lg overflow-hidden border border-gray-300 mb-2">
                    <div class="flex px-2 py-3">
                        <img class="w-12 h-12 object-cover rounded-full mt-8" src="<?php echo e($notification->data['avatar']); ?>">
                        <div class="mx-3 self-center">
                            <h2 class="text-xl font-semibold text-gray-800">User <a
                                    href="<?php echo e(route('profile', $notification->data['username'])); ?>"
                                    class="text-blue-500"><?php echo e('@' . $notification->data['username']); ?>

                                </a> posted new tweet <span class="text-blue-500 text-sm font-semibold"><?php echo e($notification->data['time']); ?></span>.</h2>
                            <p class="text-gray-600"><?php echo e($notification->data['tweet']); ?></p>
                            <?php if(($notification->data['image'])): ?>
                                <img src="<?php echo e($notification->data['image']); ?>" alt=""
                                     class="my-2 w-auto h-40 object-cover">
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

            <?php if($notification->type === 'App\Notifications\UserMentioned'): ?>
                <div class="border-l-4 border-blue-500 rounded-lg">
                    <div class="flex w-full bg-white shadow-lg rounded-lg overflow-hidden border border-gray-300 mb-2">
                        <div class="px-2 py-3 flex">
                            <img class="w-12 h-12 object-cover rounded-full mt-4" src="<?php echo e($notification->data['avatar']); ?>">
                            <div class="px-2">
                                <h2 class="text-xl font-semibold text-gray-800">User <a
                                        href="<?php echo e(route('profile' , $notification->data['username'])); ?>"
                                        class="text-blue-500"><?php echo e('@' . $notification->data['username']); ?></a>
                                    mention to you!!
                                </h2>
                            </div>
                        </div>

                    </div>
                </div>
            <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="border-l-4 border-blue-500 rounded-lg">
            <div class=" w-full bg-white shadow-lg rounded-lg border border-gray-300 mb-2">
                <div class=" px-2 py-3">
                    <p class="text-md text-green-400">No notificatoins yet!!</p>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <div class="mt-8">
        <?php echo e($notifications->links('pagination::tailwind')); ?>

    </div>
 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\PHPproject\laravelproject\tweety\resources\views/notificatoins/show.blade.php ENDPATH**/ ?>