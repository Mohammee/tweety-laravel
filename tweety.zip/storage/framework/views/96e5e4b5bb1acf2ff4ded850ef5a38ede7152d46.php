

<div class="border border-grey-300 rounded-2xl">

    <?php $__empty_1 = true; $__currentLoopData = $tweets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tweet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php echo $__env->make('-tweet', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class=" my-4  pl-4  text-sm text-blue-400">No Tweets Yet!!</p>
    <?php endif; ?>


     <?php echo e($tweets->links('pagination::tailwind')); ?>

</div>
<?php /**PATH C:\PHPproject\laravelproject\tweety\resources\views/_timeline.blade.php ENDPATH**/ ?>