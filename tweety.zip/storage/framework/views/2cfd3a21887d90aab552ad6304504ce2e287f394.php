<?php if (! (current_user()->is($user))): ?>
    <form method="POST" action="<?php echo e(route('follow',$user->username)); ?>">
        <?php echo csrf_field(); ?>
        <button type="submit"
                class=" <?php if(current_user()->following($user)): ?> bg-red-400 <?php else: ?>  bg-blue-400  hover:bg-blue-600 <?php endif; ?>
                    text-xs text-white font-bold py-2 px-4 rounded-full">
            <?php echo e(current_user()->following($user) ? 'Un Follow' : 'Follwo Me'); ?>

        </button>
    </form>

<?php endif; ?>
<?php /**PATH C:\PHPproject\laravelproject\tweety\resources\views/components/follow-button.blade.php ENDPATH**/ ?>