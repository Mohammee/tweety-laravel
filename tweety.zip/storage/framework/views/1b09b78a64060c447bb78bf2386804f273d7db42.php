<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.app','data' => []]); ?>
<?php $component->withName('app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <h2 class="font-bold text-lg mb-4 text-gray-700">Edit profile :)</h2>

    <form method="POST" action="<?php echo e($user->profilePath('update')); ?>" enctype="multipart/form-data">

        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>

        <div class="mb-6">
            <label for="username" class=" block text-xs text-gray-700 font-bold uppercase mb-2">
                UserName
            </label>
            <input required value="<?php echo e($user->username); ?>" type="text" id="username" name="username"
                   class="<?php if($errors->has('username')): ?> border border-red-500 <?php else: ?> border border-gray-300 <?php endif; ?> p-2 w-full">
            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-red-600  text-sm"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-6">
            <label for="name" class=" block text-xs text-gray-700 font-bold uppercase mb-2">
                Name
            </label>
            <input required value="<?php echo e($user->name); ?>" type="text" id="name" name="name"
                   class=" <?php if($errors->has('name')): ?> border border-red-500 <?php else: ?> border border-gray-300 <?php endif; ?> p-2 w-full">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-red-600  text-sm"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-6">
            <label for="email" class=" block text-xs text-gray-700 font-bold uppercase mb-2">
                Email
            </label>
            <input required value="<?php echo e($user->email); ?>" type="email" id="email" name="email"
                   class=" <?php if($errors->has('email')): ?> border border-red-500 <?php else: ?> border border-gray-300 <?php endif; ?> p-2 w-full">
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-red-600  text-sm"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-6">
            <label for="desc" class="block text-xs text-gray-700 font-bold uppercase mb-2">
                Description
            </label>

            <textarea id="desc" name="description" class="w-full
            <?php if($errors->has('description')): ?> border border-red-500
            <?php else: ?> border border-gray-300
            <?php endif; ?> ">
                <?php echo e($user->description); ?>

            </textarea>

            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-red-600  text-sm"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>


        <div class="mb-6">
            <label for="avatar" class=" block text-xs text-gray-700 font-bold uppercase mb-2">
                Avatar
            </label>
            <div class="flex">
                <input type="file" id="avatar" name="avatar"
                       class=" <?php if($errors->has('avatar')): ?> border border-red-500 <?php else: ?> border border-gray-300 <?php endif; ?> p-2 w-full">

                <img
                    src="<?php echo e($user->avatar); ?>"
                    id="show_avatar"
                    alt="your avatar"
                    class="h-12 w-12 object-cover"
                >
            </div>

            <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-red-600  text-sm"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>


        <div class="mb-6">
            <label for="banner" class=" block text-xs text-gray-700 font-bold uppercase mb-2">
                Banner
            </label>
            <div class="flex">
                <input type="file" id="banner" name="banner"
                       class=" <?php if($errors->has('banner')): ?> border border-red-500 <?php else: ?> border border-gray-300 <?php endif; ?> p-2 w-full">

                <img
                    src="<?php echo e($user->banner); ?>"
                    alt="your banner"
                    id="show_banner"
                    class="h-12 w-28 object-cover"
                >
            </div>

            <?php $__errorArgs = ['banner'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-red-600  text-sm"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>


        <div class="mb-6">
            <label for="password" class=" block text-xs text-gray-700 font-bold uppercase mb-2">
                Password
            </label>
            <input  type="password" id="password" name="password" placeholder="change your password if you wont(iptional)"
                   class=" <?php if($errors->has('password')): ?> border border-red-500 <?php else: ?> border border-gray-300 <?php endif; ?> p-2 w-full">
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-red-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-6">
            <label for="confpassword" class=" block text-xs text-gray-700 font-bold uppercase mb-2">
                Conform Password
            </label>
            <input  type="password" id="confpassword" name="password_confirmation"
                   class="<?php if($errors->has('password')): ?> border border-red-500 <?php else: ?> border border-gray-300 <?php endif; ?> p-2 w-full">
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-red-600  text-sm"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>


        <button class="border border-blue-400 bg-blue-300 rounded-lg px-4 py-2 mr-4" type="submit">Update</button>
        <a href="<?php echo e($user->profilePath()); ?>" class="hover:underline text-xl">Cancel</a>
    </form>
 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\PHPproject\laravelproject\tweety\resources\views/profile/edit.blade.php ENDPATH**/ ?>