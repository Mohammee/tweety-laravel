<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.master','data' => []]); ?>
<?php $component->withName('master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <div class="container  mx-6 py-6 px-4 mx-auto">
        <div class="row flex justify-center ">

            <div class="w-96 pt-8 px-10  bg-blue-200 rounded-2xl">


                <div class="flex justify-between">

                    <div class="font-bold text-xl mb-4"><?php echo e(__('Register')); ?></div>

                    <div><a class="bg-blue-500 my-6 rounded-sm text-sm py-3 px-6 uppercase text-white"
                            href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a></div>
                </div>

                <form method="POST" action="<?php echo e(route('register')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="form-group row">
                        <label for="username"
                               class="block text-xs text-gray-700 font-bold uppercase"><?php echo e(__('Username')); ?></label>

                        <div class="col-md-6 ">
                            <input id="username" type="text"
                                   class="w-full py-2 mb-2 <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-red-800 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="username"
                                   value="<?php echo e(old('username')); ?>" required autocomplete="username" autofocus>

                            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-600 text-xs" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        <label for="name"
                               class="block text-xs text-gray-700 font-bold uppercase"><?php echo e(__('Name')); ?></label>

                        <div class="col-md-6 ">
                            <input id="name" type="text"
                                   class="w-full py-2 mb-2 <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-red-800 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name"
                                   value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>

                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-600 text-xs" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        <label for="email"
                               class="block text-xs text-gray-700 font-bold uppercase"><?php echo e(__('E-Mail Address')); ?></label>

                        <div class="col-md-6 ">
                            <input id="email" type="email"
                                   class=" w-full  py-2 mb-2 <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-red-800 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email"
                                   value="<?php echo e(old('email')); ?>" required autocomplete="email">

                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-600 text-xs" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        <label for="password"
                               class="block text-xs text-gray-700 font-bold uppercase"><?php echo e(__('Password')); ?></label>

                        <div class="col-md-6 ">
                            <input id="password" type="password"
                                   class="w-full py-2 mb-2 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-red-800 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   name="password" required autocomplete="new-password">

                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-600 text-xs" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        <label for="password-confirm"
                               class="block text-xs text-gray-700 font-bold uppercase"><?php echo e(__('Confirm Password')); ?></label>

                        <div class="col-md-6 ">
                            <input id="password-confirm" type="password" class="w-full py-2 mb-2"
                                   name="password_confirmation" required autocomplete="new-password">
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit"
                                        class="bg-blue-500 my-6 rounded-sm text-sm py-3 px-6 uppercase text-white">
                                    <?php echo e(__('Register')); ?>

                                </button>
                            </div>
                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>


 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\PHPproject\laravelproject\tweety\resources\views/auth/register.blade.php ENDPATH**/ ?>