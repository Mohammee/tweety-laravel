<section class="px-8">
    <main class="container mx-auto">

        <div class="lg:flex lg:justify-between">

            <div class="lg:w-32 mb-4">
                <?php echo $__env->make('_sidebar_links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <button class="bg-blue-400 hover:bg-blue-600 text-white font-bold p-2 rounded-lg">
                    Tweet-a-roo!
                </button>
            </div>

            <div class="lg:flex-1 lg:mx-10" style="max-width: 700px">
                <?php echo $__env->yieldContent('content'); ?>
            </div>

            <div  class="lg:w-1/5">
                <?php echo $__env->yieldContent('friends'); ?>
            </div>

        </div>

    </main>
</section>

<?php echo $__env->make('component.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\PHPproject\laravelproject\tweety\resources\views/component/app.blade.php ENDPATH**/ ?>