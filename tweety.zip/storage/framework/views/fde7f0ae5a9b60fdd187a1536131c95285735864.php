<ul>
    <li>
        <a href="<?php echo e(route('home')); ?>" class="font-bold block mb-4 text-lg">Home</a>
    </li>
    <li>
        <a href="/explore" class="font-bold block mb-4 text-lg">Explore</a>
    </li>
    <li>
        <a href="/notifications" class="font-bold block mb-4 text-lg">Notifications</a>
    </li>

    <?php if(auth()->guard()->check()): ?>
    <li>
        <a href="<?php echo e(auth()->user()->profilePath()); ?>" class="font-bold block mb-4 text-lg">Profile</a>
    </li>
    <?php endif; ?>

    <li>
        
        
        
        

        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button class="font-bold  mb-4 text-lg">Logout</button>
        </form>
    </li>
</ul>
<?php /**PATH C:\PHPproject\laravelproject\tweety\resources\views/_sidebar_links.blade.php ENDPATH**/ ?>