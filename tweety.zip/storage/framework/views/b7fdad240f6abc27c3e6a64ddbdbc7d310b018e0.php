<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.app','data' => []]); ?>
<?php $component->withName('app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>


    <header class="mb-6">

        <div class="relative">
            <img class="rounded-2xl w-full object-cover" src="<?php echo e($user->banner); ?>"
                 alt="Banner profile image" style="width:611.2px; height:194.717px">

            <a href="<?php echo e($user->profilePath()); ?>">
                <img src="<?php echo e($user->avatar); ?>"
                     class=" absolute rounded-full bottom-0 transform -translate-x-1/2 translate-y-1/2"
                     style="left: 50%;width: 150px ; height: 150px"
                     alt="your avatar"
                >
            </a>
        </div>


        <div class="lg:flex lg:justify-between  mt-4 mb-6 items-center">

            <div style="max-width: 200px">
                <h3 class="text-xl mb-0 font-bold text-gray-700"><?php echo e($user->name); ?></h3>
                <p class="text-sm">Joined: <?php echo e($user->created_at->diffForHumans()); ?></p>
            </div>

            <?php if(auth()->guard()->check()): ?>
            <div class="flex">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit' , $user)): ?>
                    <a href="<?php echo e($user->profilePath('edit')); ?>">
                        <button
                            class="border border-gray-300 text-xs mr-2
                   font-bold py-2 px-4 rounded-full">
                            Edit Profile
                        </button>
                    </a>
                <?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.follow-button','data' => ['user' => $user]]); ?>
<?php $component->withName('follow-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($user)]); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            </div>
            <?php endif; ?>

        </div>

        <p class="text-sm"><?php echo e($user->description); ?></p>


    </header>


    <?php echo $__env->make('_timeline' , ['tweets' => $tweets], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\PHPproject\laravelproject\tweety\resources\views/profile/show.blade.php ENDPATH**/ ?>