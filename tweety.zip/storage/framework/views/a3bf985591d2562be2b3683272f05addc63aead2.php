<div class="border border-blue-500 rounded-2xl px-8 py-6 mb-8">

    <form method="POST" action="/tweets" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="flex">
            <input id="counter" type="text" disabled class="bg-white font-bold text-sm mb-1">
        </div>

        <div class="relative show_users">
            <textarea
                required
                autofocus
                placeholder="What's up doc?"
                class="w-full textarea h-20 "
                name="body" onkeyup="textCounter(this,'counter' , 255)"></textarea>
        </div>

        <div class="image-upload">
            <label class="text-blue-500" for="file-input" id="upload">
                <img src="<?php echo e(asset('image/photo-upload.png')); ?>" alt="" class="h-8 w-8 mt-4">
            </label>

            <input id="file-input" type="file" name="image" style="display: none" />

             <div class="relative h-60 w-80 m-2"  style="display: none" id="show_image">
                 <img src="" alt="upload image" id="image_upload"
                 class="w-full h-full object-cover">

                 <button class="text-white absolute top-0 right-0 p-2 font-bold text-xl" id="remove_image">X</button>
             </div>
        </div>

        <hr class="mb-4 mt-2">

        <footer class="flex justify-between items-center">
            <a href="<?php echo e(auth()->user()->profilePath()); ?>"><img src="<?php echo e(auth()->user()->avatar); ?>"
                 alt="your avatar"
                 class="rounded-full mr-2" style="width: 40px; height: 40px"
            >
            </a>


            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.publish-button','data' => []]); ?>
<?php $component->withName('publish-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

        </footer>

    </form>

    <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
     <p class="text-red-400 mt-2 text-sm"><?php echo e($message); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php /**PATH C:\PHPproject\laravelproject\tweety\resources\views/_publish_tweet_panel.blade.php ENDPATH**/ ?>