<div class="flex p-4 <?php echo e($loop->last ? '' : 'border-b border-b-grey-300'); ?> tweet">
    <div class="mr-4 flex-shrink-0">
        <a href="<?php echo e($tweet->user->profilePath()); ?>">
            <img
                src="<?php echo e($tweet->user->avatar); ?>"
                alt=""
                class="rounded-full w-12 h-12 object-cover"
            >
        </a>
    </div>

    <div>

        <div class="flex items-center mb-4">

            <a href="<?php echo e($tweet->user->profilePath()); ?>">
                <h5 class="font-bold text-gray-700 mr-4"><?php echo e($tweet->user->name); ?></h5>
            </a>

            <p class="text-xs"><?php echo e($tweet->created_at->diffForHumans()); ?></p>

            <?php if(auth()->guard()->check()): ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.delete-tweet-button','data' => ['tweet' => $tweet]]); ?>
<?php $component->withName('delete-tweet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['tweet' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($tweet)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <?php endif; ?>

        </div>

        <p class="text-sm mb-3"><?php echo $tweet->body; ?></p>
        <?php if($tweet->image): ?>
            <img src="<?php echo e($tweet->image); ?>" class="block mb-2 h-80 object-cover"/>
        <?php endif; ?>

        <?php if(auth()->guard()->check()): ?>
        
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.like-button','data' => ['tweet' => $tweet]]); ?>
<?php $component->withName('like-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['tweet' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($tweet)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php endif; ?>


    </div>

</div>
<?php /**PATH C:\PHPproject\laravelproject\tweety\resources\views/-tweet.blade.php ENDPATH**/ ?>